Did you already UNZIP RFM to ../responsivefilemanager/ ?

We want this structure to exist...
assets/components/tinymcewrapper/responsivefilemanager/filemanager/config/

The only alteration to this RFManager is the config.php filemanager
Only two lines were altered, 1 and 338
If you want to use your own RFM go ahead!!!

To use with MODx
Copy all these files in this folder /rfmConfigForModx/   to 
assets/components/tinymcewrapper/responsivefilemanager/filemanager/config/

OPEN:
config/config.inc.php

ENTER:
The path/to/your/modx/core/

CHANGE the upload/thumbs folder to suit you

NOTE:
You don't need to touch anything in the config.php; but do look in that file to see all the comments on what this or that does.

The tonne of options have been copied to config.personal.php

Customize it, place it in the upload directory, and rename to config.php
If you are using sub personal upload folders, and wish to further customize what this or that person can and cannot do, do the same, copy the file to each personal folder, and customize accordingly.

ENJOY!!!!