
TinymceWrapper


Author: donShakespeare 
Copyright 2015

Official Documentation: http://www.leofec.com/modx-revolution/tinymce-wrapper-for-modx-manager.html

Bugs and Feature Requests: https://github.com/donShakespeare/TinymceWrapper

Questions: http://forums.modx.com

Created by MyComponent
